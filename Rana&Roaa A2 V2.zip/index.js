const JSON_URL = 'https://raw.githubusercontent.com/RoaaAlshamrani/myFirstRepo/master/COVID07122020.json';
const WIDTH = 1500;
const HEIGHT = 1500;

const addCovidStatus = (arr, el) => {
    let obj = arr.find((e) => {
        return e.name == el['COVID-19 status'];;
    });

    if (obj) {
        return obj;
    }

    obj = {
        name: el['COVID-19 status'],
        children: [],
    };

    arr.push(obj);

    return obj;
};

const addNationality = (arr, el) => {
    let obj = arr.find((e) => {
        return e.name == el.Nationality;
    });

    if (obj) {
        return obj;
    }

    obj = {
        name: el.Nationality,
        children: [],
    };

    arr.push(obj);

    return obj;
};

const addHeartStatus = (arr, el) => {
    let obj = arr.find((e) => {
        return e.name == el['Heart Failure'];
    });

    if (obj) {
        obj.value++;
        return obj;
    }
    console.log(el['Heart Failure'])
    obj = {
        name: el['Heart Failure'],
        value: 1,
    };

    arr.push(obj);

    return obj;
};

const transformData = (data) => {
    let root = data.reduce((res, el) => {
        let nationalityObj = addNationality(res.children, el);
        let covidstatusObj = addCovidStatus(nationalityObj.children, el);
        addHeartStatus(covidstatusObj.children, el);

        return res;
    }, { children: [] });

    return root;
};

const render = () => {
    // set the dimensions and margins of the graph
    let margin = {top: 10, right: 10, bottom: 10, left: 10},
      width = WIDTH - margin.left - margin.right,
      height = HEIGHT - margin.top - margin.bottom;

    // append the svg object to the body of the page
    let svg = d3.select("#graph")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    $.get(JSON_URL, (result) => {
        let data = JSON.parse(result);

        let transformedData = transformData(data);
        let root = d3.hierarchy(transformedData).sum(d => d.value);

        d3.treemap()
            .size([width, height])
            .paddingTop(20)
            .paddingRight(7)
            .paddingInner(3)      // Padding between each rectangle
            (root);

        let color = d3.scaleOrdinal()
            .domain(['Female', 'Male'])
            .range([ '#402D54', '#8FD175']);

        let opacity = d3.scaleLinear()
            .domain([0, 100])
            .range([.5,1]);

        // use this information to add rectangles:
        svg.selectAll("rect")
            .data(root.leaves())
            .enter()
            .append("rect")
            .attr('x', d =>  d.x0)
            .attr('y', d =>  d.y0)
            .attr('width', d => d.x1 - d.x0)
            .attr('height', d => d.y1 - d.y0)
            .style("stroke", "black")
            .style("fill", d => color(d.parent.parent.data.name))
            .style("opacity", d => opacity(d.data.value));

        console.log(root);

        // and to add the text labels
        svg.selectAll("text")
            .data(root.leaves())
            .enter()
            .append("text")
            .attr("x", d => d.x0 + 5)    // +10 to adjust position (more right)
            .attr("y", d => d.y0 + 20)    // +20 to adjust position (lower)
            .text(d => fun(d.data.name))
            .attr("font-size", "10px")
            .attr("fill", "white");

        // and to add the text labels
        svg.selectAll("vals")
            .data(root.leaves())
            .enter()
            .append("text")
            .attr("x", d => d.x0 + 5)    // +10 to adjust position (more right)
            .attr("y", d => d.y0 + 35)    // +20 to adjust position (lower)
            .text(d => d.parent.data.name)
            .attr("font-size", "10px")
            .attr("fill", "white");

        // Add title for the 3 groups
        svg.selectAll("titles")
            .data(root.descendants().filter(d => d.depth==1))
            .enter()
            .append("text")
            .attr("x", d => d.x0)
            .attr("y", d => d.y0+21)
            .text(d => d.data.name)
            .attr("font-size", "19px")
            .attr("fill",  d => color(d.data.name));
            
        function fun(str) {
            if (str)
                return "heart failure";
            else
                return "no heart failure";
        }
    });
};
